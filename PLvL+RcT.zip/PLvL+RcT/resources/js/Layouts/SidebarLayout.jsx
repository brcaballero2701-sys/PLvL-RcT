import { useState } from 'react';
import { Head, Link, usePage } from '@inertiajs/react';
import { 
    Users, Shield, Clock, TrendingUp, Activity, UserCheck, 
    Settings, BarChart3, History, UserCircle, LogOut, 
    Menu, X, Home, FileText, Bell, ChevronDown, ChevronUp
} from 'lucide-react';

export default function SidebarLayout({ title, children, header }) {
    const { auth, systemSettings, ziggy } = usePage().props;
    const user = auth.user;
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [adminMenuOpen, setAdminMenuOpen] = useState(false);

    // Función para determinar si una ruta está activa
    const isActiveRoute = (routeName) => {
        const currentPath = ziggy?.location || window.location.pathname;
        
        if (routeName === 'dashboard') {
            return currentPath === '/dashboard';
        }
        if (routeName === 'admin.dashboard') {
            return currentPath.includes('/admin/dashboard') || currentPath.endsWith('/admin');
        }
        if (routeName === 'guardia.dashboard') {
            return currentPath.includes('/guardia');
        }
        
        return currentPath.includes(routeName.replace('.', '/'));
    };

    // Configuración de navegación basada en el rol
    const getNavigationItems = () => {
        const commonItems = [
            {
                name: 'Dashboard Principal',
                href: route('dashboard'),
                icon: Home,
                active: isActiveRoute('dashboard'),
                show: true
            }
        ];

        const adminItems = user.role === 'admin' ? [
            {
                name: 'Panel Administrativo',
                href: route('admin.dashboard'),
                icon: BarChart3,
                active: isActiveRoute('admin.dashboard'),
                show: true
            },
            {
                name: 'Instructores',
                href: route('admin.instructores.index'),
                icon: Users,
                active: isActiveRoute('admin.instructores'),
                show: true
            },
            {
                name: 'Historial',
                href: route('admin.historial'),
                icon: History,
                active: isActiveRoute('admin.historial'),
                show: true
            },
            {
                name: 'Reportes',
                href: route('admin.reportes'),
                icon: FileText,
                active: isActiveRoute('admin.reportes'),
                show: true
            },
            {
                name: 'Configuraciones',
                href: route('admin.configuraciones'),
                icon: Settings,
                active: isActiveRoute('admin.configuraciones'),
                show: true
            },
            {
                name: 'Vigilantes',
                href: route('admin.vigilantes'),
                icon: Shield,
                active: isActiveRoute('admin.vigilantes'),
                show: true
            },
            {
                name: 'Usuarios',
                href: route('admin.users.index'),
                icon: UserCheck,
                active: isActiveRoute('admin.users'),
                show: true
            }
        ] : [];

        const guardiaItems = user.role === 'guardia' ? [
            {
                name: 'Control de Asistencia',
                href: route('guardia.dashboard'),
                icon: Clock,
                active: isActiveRoute('guardia.dashboard'),
                show: true
            }
        ] : [];

        return [...commonItems, ...adminItems, ...guardiaItems];
    };

    const navigationItems = getNavigationItems();

    return (
        <div className="flex h-screen overflow-hidden bg-gray-100">
            <Head title={title} />
            
            {/* Overlay para móvil */}
            {sidebarOpen && (
                <div 
                    className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
                    onClick={() => setSidebarOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside className={`fixed left-0 top-0 h-screen bg-green-700 text-white w-64 flex flex-col shadow-lg z-50 transform transition-transform duration-300 ease-in-out ${
                sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
            }`}>
                {/* Header del sidebar */}
                <div className="flex flex-col items-center p-6 border-b border-green-600">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-3 shadow-md">
                        <div className="text-green-600 font-bold text-lg">SENA</div>
                    </div>
                    <h1 className="text-xl font-semibold text-center leading-tight">
                        {systemSettings?.system_name || 'Gestión Instructores SENA'}
                    </h1>
                    <div className="mt-2 text-center">
                        <p className="text-sm text-green-100">{user.name}</p>
                        <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                            user.role === 'admin' 
                                ? 'bg-red-100 text-red-800' 
                                : user.role === 'guardia'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-gray-100 text-gray-800'
                        }`}>
                            {user.role === 'admin' ? 'Administrador' : user.role === 'guardia' ? 'Guardia' : 'Usuario'}
                        </span>
                    </div>
                </div>
                
                {/* Navegación principal */}
                <nav className="flex flex-col gap-2 flex-1 p-6 overflow-y-auto">
                    {navigationItems.map((item) => {
                        if (!item.show) return null;
                        
                        const Icon = item.icon;
                        return (
                            <Link 
                                key={item.name}
                                href={item.href} 
                                className={`rounded-lg px-4 py-3 transition-all duration-200 hover:shadow-md flex items-center gap-3 text-sm font-medium ${
                                    item.active 
                                        ? 'bg-green-600 font-semibold shadow-md border-l-4 border-white' 
                                        : 'hover:bg-green-600'
                                }`}
                                onClick={() => setSidebarOpen(false)} // Cerrar sidebar en móvil
                            >
                                <Icon size={18} />
                                <span>{item.name}</span>
                            </Link>
                        );
                    })}
                </nav>

                {/* Botón de cerrar sesión */}
                <div className="p-6 border-t border-green-600">
                    <Link
                        href={route('logout')}
                        method="post"
                        as="button"
                        className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-all duration-200 hover:shadow-md"
                    >
                        <LogOut size={18} />
                        <span>Cerrar Sesión</span>
                    </Link>
                </div>
            </aside>

            {/* Contenido principal */}
            <div className="flex-1 flex flex-col lg:ml-64">
                {/* Header móvil */}
                <div className="lg:hidden bg-white shadow-sm border-b border-gray-200 p-4 flex items-center justify-between">
                    <button
                        onClick={() => setSidebarOpen(true)}
                        className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                    >
                        <Menu size={24} />
                    </button>
                    <h1 className="text-lg font-semibold text-gray-900">{title}</h1>
                    <div className="w-8 h-8"></div> {/* Spacer */}
                </div>

                {/* Header de página */}
                {header && (
                    <header className="bg-white shadow-sm border-b border-gray-200">
                        <div className="px-6 py-4">
                            {header}
                        </div>
                    </header>
                )}

                {/* Contenido */}
                <main className="flex-1 overflow-y-auto bg-gray-50">
                    {children}
                </main>
            </div>
        </div>
    );
}