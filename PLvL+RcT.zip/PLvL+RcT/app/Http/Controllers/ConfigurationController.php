<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class ConfigurationController extends Controller
{
    public function index()
    {
        // Obtener todos los usuarios con sus datos reales
        $usuarios = User::select('id', 'name', 'email', 'role', 'codigo_guardia', 'ubicacion_asignada', 'turno_activo', 'created_at')
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(function ($user) {
                return [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                    'codigo_guardia' => $user->codigo_guardia,
                    'ubicacion_asignada' => $user->ubicacion_asignada,
                    'status' => $user->turno_activo ? 'Activo' : 'Inactivo',
                    'created_at' => $user->created_at->format('d/m/Y'),
                    'avatar' => 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=random'
                ];
            });

        // Estadísticas de roles reales
        $rolesStats = [
            'admin' => User::where('role', 'admin')->count(),
            'guardia' => User::where('role', 'guardia')->count(),
            'user' => User::where('role', 'user')->count(),
        ];

        // Configuraciones del sistema (estas pueden estar en una tabla de configuraciones)
        $systemSettings = [
            'app_name' => config('app.name', 'Sistema de Vigilancia'),
            'max_users' => 100,
            'backup_enabled' => true,
            'notifications_enabled' => true,
            'auto_logout_time' => 30,
            'password_complexity' => true,
            'two_factor_enabled' => false,
            'maintenance_mode' => false,
        ];

        return Inertia::render('Configuration', [
            'usuarios' => $usuarios,
            'rolesStats' => $rolesStats,
            'systemSettings' => $systemSettings
        ]);
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => ['required', Rules\Password::defaults()],
            'role' => 'required|in:admin,guardia,user',
            'codigo_guardia' => 'nullable|string|max:20|unique:users',
            'ubicacion_asignada' => 'nullable|string|max:255',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'codigo_guardia' => $request->codigo_guardia,
            'ubicacion_asignada' => $request->ubicacion_asignada,
        ]);

        return redirect()->back()->with('success', 'Usuario creado correctamente');
    }

    public function updateUser(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'role' => 'required|in:admin,guardia,user',
            'codigo_guardia' => 'nullable|string|max:20|unique:users,codigo_guardia,' . $user->id,
            'ubicacion_asignada' => 'nullable|string|max:255',
        ]);

        $user->update($request->only('name', 'email', 'role', 'codigo_guardia', 'ubicacion_asignada'));

        return redirect()->back()->with('success', 'Usuario actualizado correctamente');
    }

    public function destroyUser(User $user)
    {
        // No permitir que el admin se elimine a sí mismo
        if ($user->id === auth()->id()) {
            return redirect()->back()->with('error', 'No puedes eliminar tu propia cuenta');
        }

        $user->delete();

        return redirect()->back()->with('success', 'Usuario eliminado correctamente');
    }

    public function toggleUserStatus(User $user)
    {
        $user->update([
            'turno_activo' => !$user->turno_activo
        ]);

        $status = $user->turno_activo ? 'activado' : 'desactivado';
        return redirect()->back()->with('success', "Usuario {$status} correctamente");
    }
}