// Componente LogoDisplay simplificado temporalmente para evitar errores
export default function LogoDisplay({ size = "default", alt = "Logo SENA", className = "" }) {
    // Determinar el tamaño según el prop
    const sizeClasses = {
        sidebar: "w-8 h-8 text-sm",
        header: "w-10 h-10 text-base", 
        large: "w-16 h-16 text-xl",
        default: "w-12 h-12 text-base"
    };

    const currentSize = sizeClasses[size] || sizeClasses.default;

    return (
        <div className={`bg-green-600 rounded-full flex items-center justify-center text-white font-bold ${currentSize} ${className}`}>
            SENA
        </div>
    );
}