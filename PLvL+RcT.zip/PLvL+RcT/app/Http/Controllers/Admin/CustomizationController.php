<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Storage;

class CustomizationController extends Controller
{
    /**
     * Mostrar la página de personalización del sistema
     */
    public function index()
    {
        $settings = SystemSetting::getCustomizationConfig();
        
        return Inertia::render('Admin/Configuraciones/Personalizacion', [
            'settings' => $settings
        ]);
    }

    /**
     * Actualizar configuraciones de personalización
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'language' => 'required|in:es,en,fr,pt',
            'color_scheme' => 'required|in:green-500,green-600,green-700,green-800,emerald-500,emerald-600,blue-500,blue-600,blue-700,blue-800,sky-500,sky-600,indigo-500,indigo-600,purple-500,purple-600,violet-500,violet-600,teal-500,teal-600,cyan-400,cyan-500,cyan-600,red-500,red-600,orange-500,orange-600,amber-500,yellow-500,slate-600,slate-700,gray-600,gray-700,zinc-600,stone-600',
            'system_name' => 'nullable|string|max:255'
        ]);

        try {
            // Guardar configuraciones
            SystemSetting::setSetting('language', $validated['language'], 'string', 'Idioma del sistema');
            SystemSetting::setSetting('color_scheme', $validated['color_scheme'], 'string', 'Esquema de colores del sistema');
            
            if (isset($validated['system_name'])) {
                SystemSetting::setSetting('system_name', $validated['system_name'], 'string', 'Nombre del sistema');
            }

            // Para Inertia.js, siempre hacer redirect con mensaje de éxito
            return redirect()->back()->with('success', 'Configuración de personalización actualizada exitosamente');
            
        } catch (\Exception $e) {
            // Para Inertia.js, siempre hacer redirect con mensaje de error
            return redirect()->back()->with('error', 'Error al actualizar la configuración: ' . $e->getMessage());
        }
    }

    /**
     * Subir nuevo logo institucional
     */
    public function uploadLogo(Request $request)
    {
        $validated = $request->validate([
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);

        try {
            // Eliminar logo anterior si existe
            $oldLogoPath = SystemSetting::getSetting('logo_path');
            if ($oldLogoPath && $oldLogoPath !== '/images/sena-logo.svg' && $oldLogoPath !== '/images/sena-logo.png') {
                $oldPath = str_replace('/storage/', '', $oldLogoPath);
                if (Storage::disk('public')->exists($oldPath)) {
                    Storage::disk('public')->delete($oldPath);
                }
            }

            // Subir nuevo logo
            $file = $request->file('logo');
            $filename = 'logo_' . time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('logos', $filename, 'public');
            $logoUrl = '/storage/' . $path;
            
            // Guardar en la base de datos
            SystemSetting::setSetting('logo_path', $logoUrl, 'string', 'Ruta del logo institucional');

            // Para Inertia.js, siempre hacer redirect con mensaje de éxito
            return redirect()->back()->with('success', 'Logo institucional actualizado exitosamente');
            
        } catch (\Exception $e) {
            \Log::error('Error al subir logo: ' . $e->getMessage());
            
            // Para Inertia.js, siempre hacer redirect con mensaje de error
            return redirect()->back()->with('error', 'Error al subir el logo: ' . $e->getMessage());
        }
    }

    /**
     * Restablecer configuraciones por defecto
     */
    public function reset()
    {
        SystemSetting::setSetting('language', 'es', 'string', 'Idioma del sistema');
        SystemSetting::setSetting('color_scheme', 'green-600', 'string', 'Esquema de colores del sistema');
        SystemSetting::setSetting('system_name', 'Gestión Instructores SENA', 'string', 'Nombre del sistema');
        SystemSetting::setSetting('logo_path', '/images/sena-logo.png', 'string', 'Ruta del logo institucional');

        return redirect()->back()->with('success', 'Configuración restablecida a valores por defecto');
    }
}
