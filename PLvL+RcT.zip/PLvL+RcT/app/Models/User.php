<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Notifications\ResetPasswordNotification;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'codigo_guardia',
        'ubicacion_asignada',
        'hora_inicio_turno',
        'hora_fin_turno',
        'ultimo_inicio_turno',
        'ultimo_fin_turno',
        'turno_activo',
        'phone',
        'recovery_code',
        'recovery_code_expires_at',
        'recovery_token',
        'recovery_attempts',
        'recovery_attempts_date',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'hora_inicio_turno' => 'datetime:H:i',
            'hora_fin_turno' => 'datetime:H:i',
            'ultimo_inicio_turno' => 'datetime',
            'ultimo_fin_turno' => 'datetime',
            'turno_activo' => 'boolean',
        ];
    }

    /**
     * Check if the user is an admin
     */
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    /**
     * Check if the user is a regular user
     */
    public function isUser(): bool
    {
        return $this->role === 'user';
    }

    /**
     * Check if the user is a guard (guardia)
     */
    public function isGuardia(): bool
    {
        return $this->role === 'guardia';
    }

    /**
     * Relación con las asistencias registradas por este guardia
     */
    public function asistenciasRegistradas(): HasMany
    {
        return $this->hasMany(Asistencia::class, 'guardia_id');
    }

    /**
     * Iniciar turno del guardia
     */
    public function iniciarTurno(): void
    {
        $this->update([
            'ultimo_inicio_turno' => now(),
            'turno_activo' => true,
        ]);
    }

    /**
     * Finalizar turno del guardia
     */
    public function finalizarTurno(): void
    {
        $this->update([
            'ultimo_fin_turno' => now(),
            'turno_activo' => false,
        ]);
    }

    /**
     * Verificar si el guardia está en turno
     */
    public function estaEnTurno(): bool
    {
        return $this->turno_activo;
    }

    /**
     * Obtener el tiempo total del último turno
     */
    public function tiempoUltimoTurno(): ?int
    {
        if ($this->ultimo_inicio_turno && $this->ultimo_fin_turno) {
            return $this->ultimo_inicio_turno->diffInMinutes($this->ultimo_fin_turno);
        }
        return null;
    }

    /**
     * Scope para guardias
     */
    public function scopeGuardias($query)
    {
        return $query->where('role', 'guardia');
    }

    /**
     * Scope para guardias en turno
     */
    public function scopeEnTurno($query)
    {
        return $query->where('turno_activo', true);
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }
}
