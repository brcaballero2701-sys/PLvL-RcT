import { useState } from 'react';
import { Head, Link, useForm, usePage } from '@inertiajs/react';
import { Clock, Users, MessageSquare, Image, Shield, Database, CheckCircle } from 'lucide-react';
import LogoDisplay from '@/Components/LogoDisplay';
import SidebarLayout from '@/Layouts/SidebarLayout';

export default function Configuraciones() {
    const { rolesStats, asistenciasStats, asistenciasRecientes, systemSettings } = usePage().props;

    const [activeSection, setActiveSection] = useState('horarios');
    const [activeSubSection, setActiveSubSection] = useState('configuracion');

    // Datos de configuración de horarios
    const { data: horarios, setData: setHorarios, post: postHorarios, processing: processingHorarios } = useForm({
        manana_inicio: '06:00',
        manana_fin: '11:45',
        tarde_inicio: '12:00',
        tarde_fin: '17:45',
        noche_inicio: '18:00',
        noche_fin: '21:45',
        desde: '',
        hasta: ''
    });

    const guardarAsistencia = () => {
        // Lógica para guardar la configuración de asistencia
        alert('Horario actualizado con éxito.');
    };

    const cancelar = () => {
        // Lógica para cancelar cambios
        window.location.reload();
    };

    // Estado para el upload de logo (simplificado)
    const [uploadStatus, setUploadStatus] = useState({ loading: false, message: '' });

    const handleLogoUpload = (event) => {
        const file = event.target.files[0];
        if (!file) return;

        setUploadStatus({ loading: true, message: 'Función de subida de logo en desarrollo...' });
        
        // Simulación temporal
        setTimeout(() => {
            setUploadStatus({ 
                loading: false, 
                message: 'Esta función estará disponible próximamente' 
            });
            setTimeout(() => setUploadStatus({ loading: false, message: '' }), 3000);
        }, 2000);
    };

    const handleLogoReset = () => {
        setUploadStatus({ loading: true, message: 'Función de reset en desarrollo...' });
        
        // Simulación temporal
        setTimeout(() => {
            setUploadStatus({ 
                loading: false, 
                message: 'Esta función estará disponible próximamente' 
            });
            setTimeout(() => setUploadStatus({ loading: false, message: '' }), 3000);
        }, 1000);
    };

    return (
        <SidebarLayout
            title="Configuraciones del Sistema - SENA"
            header={
                <div>
                    <h1 className="text-3xl font-bold text-gray-800">Configuraciones del Sistema</h1>
                    <p className="text-gray-600 mt-1">Administra parámetros generales, roles y opciones avanzadas</p>
                </div>
            }
        >
            <div className="flex">
                {/* Sidebar de opciones */}
                <aside className="w-96 bg-white border-r border-gray-200 p-6">
                    <nav className="space-y-2">
                        <button
                            onClick={() => setActiveSection('horarios')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'horarios' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <Clock className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Horarios y Asistencias</span>
                        </button>

                        <button
                            onClick={() => setActiveSection('usuarios')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'usuarios' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <Users className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Usuarios y Roles</span>
                        </button>

                        <button
                            onClick={() => setActiveSection('mensajes')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'mensajes' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <MessageSquare className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Mensajes flash / Notificaciones</span>
                        </button>

                        <button
                            onClick={() => setActiveSection('personalizacion')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'personalizacion' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <Image className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Personalización del Sistema</span>
                        </button>

                        <button
                            onClick={() => setActiveSection('seguridad')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'seguridad' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <Shield className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Seguridad y Contraseñas</span>
                        </button>

                        <button
                            onClick={() => setActiveSection('respaldo')}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                                activeSection === 'respaldo' 
                                    ? 'bg-gray-100 border-2 border-gray-300' 
                                    : 'hover:bg-gray-50'
                            }`}
                        >
                            <Database className="text-gray-600" size={20} />
                            <span className="text-gray-800 font-medium">Respaldo y Restauración</span>
                        </button>
                    </nav>
                </aside>

                {/* Contenido principal */}
                <main className="flex-1 p-8">
                    {/* Sección Horarios y Asistencias */}
                    {activeSection === 'horarios' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Horarios y Asistencias</h2>
                            <p className="text-gray-600 mb-8">Configuración de intervalos de trabajo y historial de asistencias</p>

                            {/* Pestañas internas para Horarios y Historial */}
                            <div className="mb-8">
                                <div className="border-b border-gray-200">
                                    <nav className="-mb-px flex space-x-8">
                                        <button
                                            onClick={() => setActiveSubSection('configuracion')}
                                            className={`py-2 px-1 border-b-2 font-medium text-sm ${
                                                activeSubSection === 'configuracion' || !activeSubSection
                                                    ? 'border-green-500 text-green-600'
                                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                            }`}
                                        >
                                            Configuración de Horarios
                                        </button>
                                        <button
                                            onClick={() => setActiveSubSection('historial')}
                                            className={`py-2 px-1 border-b-2 font-medium text-sm ${
                                                activeSubSection === 'historial'
                                                    ? 'border-green-500 text-green-600'
                                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                            }`}
                                        >
                                            Historial de Asistencias
                                        </button>
                                    </nav>
                                </div>
                            </div>

                            {/* Contenido de Configuración de Horarios */}
                            {(!activeSubSection || activeSubSection === 'configuracion') && (
                                <div className="space-y-6">
                                    {/* Horario Mañana */}
                                    <div className="flex items-center gap-4">
                                        <div className="w-48">
                                            <span className="text-lg font-medium text-gray-800">06:00AM-11:45AM</span>
                                            <span className="text-gray-600 ml-2">(mañana)</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <input
                                                type="time"
                                                value={horarios.manana_fin}
                                                onChange={(e) => setHorarios('manana_fin', e.target.value)}
                                                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-400"
                                            />
                                            <span className="text-gray-600">PM</span>
                                        </div>
                                    </div>

                                    {/* Horario Tarde */}
                                    <div className="flex items-center gap-4">
                                        <div className="w-48">
                                            <span className="text-lg font-medium text-gray-800">12:00PM-05:45PM</span>
                                            <span className="text-gray-600 ml-2">(tarde)</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <input
                                                type="time"
                                                value={horarios.tarde_fin}
                                                onChange={(e) => setHorarios('tarde_fin', e.target.value)}
                                                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-gray-400"
                                            />
                                            <span className="text-gray-600">PM</span>
                                        </div>
                                    </div>

                                    {/* Horario Noche */}
                                    <div className="flex items-center gap-4">
                                        <div className="w-48">
                                            <span className="text-lg font-medium text-gray-800">06:00PM-09:45PM</span>
                                            <span className="text-gray-600 ml-2">(noche)</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <input
                                                type="text"
                                                placeholder="Desde"
                                                value={horarios.desde}
                                                onChange={(e) => setHorarios('desde', e.target.value)}
                                                className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 placeholder-gray-400"
                                            />
                                            <input
                                                type="text"
                                                placeholder="Hasta"
                                                value={horarios.hasta}
                                                onChange={(e) => setHorarios('hasta', e.target.value)}
                                                className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 placeholder-gray-400"
                                            />
                                        </div>
                                    </div>

                                    {/* Botón Agregar asistencia */}
                                    <div className="mt-8">
                                        <button
                                            onClick={guardarAsistencia}
                                            className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg"
                                        >
                                            Agregar asistencia
                                        </button>
                                    </div>

                                    {/* Botones de acción */}
                                    <div className="flex gap-4 mt-8">
                                        <button
                                            onClick={guardarAsistencia}
                                            className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-6 rounded-lg"
                                        >
                                            Guardar
                                        </button>
                                        <button
                                            onClick={cancelar}
                                            className="bg-white border border-red-300 text-red-600 hover:bg-red-50 font-medium py-3 px-6 rounded-lg"
                                        >
                                            Cancelar
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Contenido del Historial de Asistencias */}
                            {activeSubSection === 'historial' && (
                                <div>
                                    {/* Estadísticas rápidas */}
                                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                                        <div className="bg-white rounded-lg p-6 border border-gray-200">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="text-sm text-gray-600 mb-1">Total Asistencias Hoy</p>
                                                    <p className="text-2xl font-bold text-gray-900">{asistenciasStats?.total_hoy || 0}</p>
                                                </div>
                                                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                                    <CheckCircle className="w-6 h-6 text-green-600" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="bg-white rounded-lg p-6 border border-gray-200">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="text-sm text-gray-600 mb-1">Llegadas Puntuales</p>
                                                    <p className="text-2xl font-bold text-gray-900">{asistenciasStats?.puntuales || 0}</p>
                                                </div>
                                                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                                    <Clock className="w-6 h-6 text-blue-600" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="bg-white rounded-lg p-6 border border-gray-200">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="text-sm text-gray-600 mb-1">Llegadas Tarde</p>
                                                    <p className="text-2xl font-bold text-gray-900">{asistenciasStats?.tarde || 0}</p>
                                                </div>
                                                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                                                    <Clock className="w-6 h-6 text-yellow-600" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="bg-white rounded-lg p-6 border border-gray-200">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <p className="text-sm text-gray-600 mb-1">Ausencias</p>
                                                    <p className="text-2xl font-bold text-gray-900">{asistenciasStats?.ausencias || 0}</p>
                                                </div>
                                                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                                                    <Users className="w-6 h-6 text-red-600" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Tabla de asistencias recientes */}
                                    <div className="bg-white rounded-lg border border-gray-200">
                                        <div className="px-6 py-4 border-b border-gray-200">
                                            <div className="flex items-center justify-between">
                                                <h3 className="text-lg font-semibold text-gray-900">Asistencias Recientes</h3>
                                                <div className="flex items-center gap-3">
                                                    <input
                                                        type="date"
                                                        className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                                                        defaultValue={new Date().toISOString().split('T')[0]}
                                                    />
                                                    <Link
                                                        href={route('admin.historial')}
                                                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                                                    >
                                                        Ver Todo
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="overflow-x-auto">
                                            {asistenciasRecientes && asistenciasRecientes.length > 0 ? (
                                                <table className="w-full">
                                                    <thead className="bg-gray-50">
                                                        <tr>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Instructor
                                                            </th>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Área
                                                            </th>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Fecha
                                                            </th>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Hora Entrada
                                                            </th>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Hora Salida
                                                            </th>
                                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                                Estado
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="bg-white divide-y divide-gray-200">
                                                        {asistenciasRecientes.map((asistencia, index) => (
                                                            <tr key={index} className="hover:bg-gray-50">
                                                                <td className="px-6 py-4 whitespace-nowrap">
                                                                    <div className="text-sm font-medium text-gray-900">
                                                                        {asistencia.instructor}
                                                                    </div>
                                                                </td>
                                                                <td className="px-6 py-4 whitespace-nowrap">
                                                                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                                                        {asistencia.area}
                                                                    </span>
                                                                </td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                                    {asistencia.fecha}
                                                                </td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                                    {asistencia.entrada}
                                                                </td>
                                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                                    {asistencia.salida}
                                                                </td>
                                                                <td className="px-6 py-4 whitespace-nowrap">
                                                                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                                                        asistencia.estado === 'Puntual' ? 'bg-green-100 text-green-800' :
                                                                        asistencia.estado === 'Tarde' ? 'bg-yellow-100 text-yellow-800' :
                                                                        asistencia.estado === 'Presente' ? 'bg-blue-100 text-blue-800' :
                                                                        'bg-red-100 text-red-800'
                                                                    }`}>
                                                                        {asistencia.estado}
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            ) : (
                                                <div className="text-center py-12">
                                                    <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                                                    <h3 className="text-sm font-medium text-gray-900 mb-2">No hay registros de asistencias hoy</h3>
                                                    <p className="text-sm text-gray-500">
                                                        Las asistencias de hoy aparecerán aquí cuando los instructores registren su entrada.
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Sección Usuarios y Roles */}
                    {activeSection === 'usuarios' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Usuarios y Roles</h2>
                            <p className="text-gray-600 mb-8">Gestiona los usuarios del sistema y sus roles asignados</p>
                            
                            {/* Estadísticas de usuarios con datos reales */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-sm text-gray-600 mb-1">Total Usuarios</p>
                                            <p className="text-2xl font-bold text-gray-900">{rolesStats?.total || 0}</p>
                                        </div>
                                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                            <Users className="w-6 h-6 text-blue-600" />
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-sm text-gray-600 mb-1">Administradores</p>
                                            <p className="text-2xl font-bold text-gray-900">{rolesStats?.admin || 0}</p>
                                        </div>
                                        <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                            <Shield className="w-6 h-6 text-green-600" />
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-sm text-gray-600 mb-1">Guardias</p>
                                            <p className="text-2xl font-bold text-gray-900">{rolesStats?.guardia || 0}</p>
                                        </div>
                                        <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                                            <Shield className="w-6 h-6 text-yellow-600" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Gestión de roles con datos dinámicos */}
                            <div className="bg-white rounded-lg p-6 border border-gray-200 mb-6">
                                <h3 className="text-lg font-semibold text-gray-800 mb-4">Roles del Sistema</h3>
                                
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                                                <Shield className="w-5 h-5 text-red-600" />
                                            </div>
                                            <div>
                                                <h4 className="font-semibold text-gray-900">Administrador</h4>
                                                <p className="text-sm text-gray-600">Acceso completo al sistema</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">
                                                {rolesStats?.admin || 0} usuarios
                                            </span>
                                            <Link
                                                href={route('admin.users.index', { role: 'admin' })}
                                                className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                            >
                                                Gestionar
                                            </Link>
                                        </div>
                                    </div>

                                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                                                <Shield className="w-5 h-5 text-yellow-600" />
                                            </div>
                                            <div>
                                                <h4 className="font-semibold text-gray-900">Guardia</h4>
                                                <p className="text-sm text-gray-600">Registro de asistencias y seguridad</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                                                {rolesStats?.guardia || 0} usuarios
                                            </span>
                                            <Link
                                                href={route('admin.users.index', { role: 'guardia' })}
                                                className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                            >
                                                Gestionar
                                            </Link>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-6 text-center">
                                    <Link
                                        href={route('admin.roles.index')}
                                        className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                                    >
                                        Ver Gestión Completa de Roles
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Sección Mensajes flash / Notificaciones */}
                    {activeSection === 'mensajes' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Mensajes flash / Notificaciones</h2>
                            <p className="text-gray-600 mb-8">Configura el comportamiento de las notificaciones del sistema</p>
                            
                            {/* Configuración de notificaciones */}
                            <div className="space-y-6">
                                {/* Colores de notificación */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Colores de Notificaciones</h3>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Notificaciones de Éxito
                                            </label>
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-green-500 rounded border border-gray-300"></div>
                                                <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                    <option value="green">Verde (por defecto)</option>
                                                    <option value="blue">Azul</option>
                                                    <option value="purple">Púrpura</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Notificaciones de Error
                                            </label>
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-red-500 rounded border border-gray-300"></div>
                                                <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                    <option value="red">Rojo (por defecto)</option>
                                                    <option value="orange">Naranja</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Notificaciones de Advertencia
                                            </label>
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-yellow-500 rounded border border-gray-300"></div>
                                                <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                    <option value="yellow">Amarillo (por defecto)</option>
                                                    <option value="orange">Naranja</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Notificaciones de Información
                                            </label>
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-blue-500 rounded border border-gray-300"></div>
                                                <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                    <option value="blue">Azul (por defecto)</option>
                                                    <option value="gray">Gris</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Configuración de comportamiento */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Configuración de Comportamiento</h3>
                                    
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Duración de las notificaciones</label>
                                                <p className="text-xs text-gray-500">Tiempo en segundos antes de que desaparezca automáticamente</p>
                                            </div>
                                            <select className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="3">3 segundos</option>
                                                <option value="5" defaultValue>5 segundos</option>
                                                <option value="8">8 segundos</option>
                                                <option value="0">Manual</option>
                                            </select>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Posición en pantalla</label>
                                                <p className="text-xs text-gray-500">Ubicación donde aparecen las notificaciones</p>
                                            </div>
                                            <select className="w-40 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="top-right" defaultValue>Arriba Derecha</option>
                                                <option value="top-left">Arriba Izquierda</option>
                                                <option value="bottom-right">Abajo Derecha</option>
                                                <option value="bottom-left">Abajo Izquierda</option>
                                                <option value="top-center">Arriba Centro</option>
                                            </select>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Sonido de notificación</label>
                                                <p className="text-xs text-gray-500">Reproducir sonido cuando aparece una notificación</p>
                                            </div>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" />
                                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                            </label>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Animación de entrada</label>
                                                <p className="text-xs text-gray-500">Efecto visual al mostrar notificaciones</p>
                                            </div>
                                            <select className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="slide" defaultValue>Deslizar</option>
                                                <option value="fade">Desvanecer</option>
                                                <option value="bounce">Rebote</option>
                                                <option value="scale">Escalar</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Vista previa */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Vista Previa</h3>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <button className="p-3 bg-green-50 border-2 border-green-200 rounded-lg text-left hover:bg-green-100 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                                <div>
                                                    <p className="font-medium text-green-800">Operación exitosa</p>
                                                    <p className="text-sm text-green-600">Los datos se guardaron correctamente</p>
                                                </div>
                                            </div>
                                        </button>

                                        <button className="p-3 bg-red-50 border-2 border-red-200 rounded-lg text-left hover:bg-red-100 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                                                <div>
                                                    <p className="font-medium text-red-800">Error en la operación</p>
                                                    <p className="text-sm text-red-600">No se pudo completar la acción</p>
                                                </div>
                                            </div>
                                        </button>

                                        <button className="p-3 bg-yellow-50 border-2 border-yellow-200 rounded-lg text-left hover:bg-yellow-100 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                                                <div>
                                                    <p className="font-medium text-yellow-800">Advertencia</p>
                                                    <p className="text-sm text-yellow-600">Revisa los datos ingresados</p>
                                                </div>
                                            </div>
                                        </button>

                                        <button className="p-3 bg-blue-50 border-2 border-blue-200 rounded-lg text-left hover:bg-blue-100 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                                                <div>
                                                    <p className="font-medium text-blue-800">Información</p>
                                                    <p className="text-sm text-blue-600">Nueva actualización disponible</p>
                                                </div>
                                            </div>
                                        </button>
                                    </div>
                                </div>

                                {/* Botones de acción */}
                                <div className="flex gap-4">
                                    <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Guardar Configuración
                                    </button>
                                    <button className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Restablecer por Defecto
                                    </button>
                                    <Link
                                        href={route('admin.notifications.index')}
                                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
                                    >
                                        Configuración Avanzada
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Sección Personalización del Sistema */}
                    {activeSection === 'personalizacion' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Personalización del Sistema</h2>
                            <p className="text-gray-600 mb-8">Personaliza la apariencia y configuración visual del sistema</p>
                            
                            {/* Vista previa del sistema actual */}
                            <div className="bg-white rounded-lg p-6 border border-gray-200 mb-6">
                                <h3 className="text-lg font-semibold text-gray-800 mb-4">Vista Previa del Sistema</h3>
                                
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <div className="bg-gray-50 rounded-lg p-4">
                                        <p className="text-sm text-gray-600 mb-2">Logo Actual</p>
                                        <div className="w-24 h-24 bg-white rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                                            <LogoDisplay 
                                                systemSettings={systemSettings} 
                                                className="w-16 h-16 object-contain"
                                                alt="Logo SENA"
                                            />
                                        </div>
                                    </div>
                                    
                                    <div className="space-y-3">
                                        <div>
                                            <p className="text-sm text-gray-600">Nombre del Sistema</p>
                                            <p className="font-semibold text-gray-900">{systemSettings?.system_name || 'Gestión Instructores SENA'}</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Esquema de Colores</p>
                                            <div className="flex items-center gap-2">
                                                <div className="w-6 h-6 bg-green-600 rounded-full border-2 border-white shadow-sm"></div>
                                                <p className="font-semibold text-gray-900">Verde SENA</p>
                                            </div>
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-600">Idioma</p>
                                            <p className="font-semibold text-gray-900">Español</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Configuraciones rápidas */}
                            <div className="space-y-6">
                                {/* Cambio de logo */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Logo Institucional</h3>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Subir Nuevo Logo
                                            </label>
                                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-400 transition-colors cursor-pointer">
                                                <input 
                                                    type="file" 
                                                    id="logoUpload"
                                                    className="hidden" 
                                                    accept="image/jpeg,image/jpg,image/png,image/svg+xml,image/webp" 
                                                    onChange={handleLogoUpload}
                                                    disabled={uploadStatus.loading}
                                                />
                                                <label htmlFor="logoUpload" className="cursor-pointer">
                                                    <div className="space-y-2">
                                                        <div className="mx-auto w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                                                            {uploadStatus.loading ? (
                                                                <div className="w-6 h-6 border-2 border-green-600 border-t-transparent rounded-full animate-spin"></div>
                                                            ) : (
                                                                <Image className="w-6 h-6 text-gray-400" />
                                                            )}
                                                        </div>
                                                        <div>
                                                            <p className="text-sm font-medium text-gray-900">
                                                                {uploadStatus.loading ? 'Subiendo...' : 'Haz clic para subir'}
                                                            </p>
                                                            <p className="text-xs text-gray-500">PNG, JPG, SVG hasta 2MB</p>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>

                                            {/* Mensaje de estado */}
                                            {uploadStatus.message && (
                                                <div className={`mt-3 p-3 rounded-lg text-sm ${
                                                    uploadStatus.message.includes('Error') 
                                                        ? 'bg-red-50 text-red-700 border border-red-200' 
                                                        : 'bg-green-50 text-green-700 border border-green-200'
                                                }`}>
                                                    {uploadStatus.message}
                                                </div>
                                            )}

                                            {/* Botón para restablecer logo */}
                                            <button
                                                onClick={handleLogoReset}
                                                disabled={uploadStatus.loading}
                                                className="mt-4 w-full px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
                                            >
                                                Restablecer Logo Predeterminado
                                            </button>
                                        </div>
                                        
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-2">
                                                Vista Previa - Actualización en Tiempo Real
                                            </label>
                                            <div className="bg-gray-50 rounded-lg p-6 h-32 flex items-center justify-center border border-gray-200">
                                                <LogoDisplay 
                                                    size="md"
                                                    variant="default"
                                                    alt="Vista previa del logo"
                                                />
                                            </div>
                                            <div className="mt-2 text-center">
                                                <p className="text-xs text-gray-500">
                                                    Logo actual: {systemSettings?.logo_path?.split('/').pop()}
                                                </p>
                                                <p className="text-xs text-green-600">
                                                    ✓ Se actualiza automáticamente en toda la aplicación
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Paleta de colores */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Esquema de Colores</h3>
                                    
                                    <div className="space-y-4">
                                        <p className="text-sm text-gray-600">Selecciona el color principal del sistema</p>
                                        
                                        <div className="grid grid-cols-6 md:grid-cols-12 gap-3">
                                            {[
                                                { color: 'bg-green-600', name: 'Verde SENA', active: true },
                                                { color: 'bg-blue-600', name: 'Azul Corporativo' },
                                                { color: 'bg-indigo-600', name: 'Índigo' },
                                                { color: 'bg-purple-600', name: 'Púrpura' },
                                                { color: 'bg-red-600', name: 'Rojo' },
                                                { color: 'bg-orange-600', name: 'Naranja' },
                                                { color: 'bg-yellow-500', name: 'Amarillo' },
                                                { color: 'bg-teal-600', name: 'Teal' },
                                                { color: 'bg-cyan-600', name: 'Cian' },
                                                { color: 'bg-gray-600', name: 'Gris' },
                                                { color: 'bg-slate-600', name: 'Pizarra' },
                                                { color: 'bg-stone-600', name: 'Piedra' }
                                            ].map((colorOption, index) => (
                                                <button
                                                    key={index}
                                                    className={`w-10 h-10 ${colorOption.color} rounded-lg border-2 transition-all hover:scale-110 ${
                                                        colorOption.active ? 'border-gray-800 ring-2 ring-gray-300' : 'border-gray-200 hover:border-gray-400'
                                                    }`}
                                                    title={colorOption.name}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                {/* Configuración de idioma */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Idioma del Sistema</h3>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {[
                                            { code: 'es', name: 'Español', flag: '🇪🇪', active: true },
                                            { code: 'en', name: 'English', flag: '🇺🇸' },
                                            { code: 'fr', name: 'Français', flag: '🇫🇷' },
                                            { code: 'pt', name: 'Português', flag: '🇵🇹' }
                                        ].map((lang) => (
                                            <button
                                                key={lang.code}
                                                className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                                                    lang.active 
                                                        ? 'border-green-500 bg-green-50 text-green-800' 
                                                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                                                }`}
                                            >
                                                <span className="text-2xl">{lang.flag}</span>
                                                <span className="font-medium">{lang.name}</span>
                                                {lang.active && <span className="ml-auto text-green-600">✓</span>}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Botones de acción */}
                                <div className="flex gap-4">
                                    <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Aplicar Cambios
                                    </button>
                                    <button className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Vista Previa
                                    </button>
                                    <Link
                                        href={route('admin.customization.index')}
                                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
                                    >
                                        Configuración Avanzada
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Sección Seguridad y Contraseñas */}
                    {activeSection === 'seguridad' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Seguridad y Contraseñas</h2>
                            <p className="text-gray-600 mb-8">Configura las políticas de seguridad del sistema</p>
                            
                            {/* Estado actual de seguridad */}
                            <div className="bg-white rounded-lg p-6 border border-gray-200 mb-6">
                                <h3 className="text-lg font-semibold text-gray-800 mb-4">Estado de Seguridad</h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                                        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                                            <Shield className="w-4 h-4 text-white" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium text-green-800">Contraseñas Seguras</p>
                                            <p className="text-xs text-green-600">Activo</p>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                        <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                                            <Shield className="w-4 h-4 text-white" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium text-yellow-800">Autenticación 2FA</p>
                                            <p className="text-xs text-yellow-600">Opcional</p>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg border border-red-200">
                                        <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                                            <Shield className="w-4 h-4 text-white" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium text-red-800">Bloqueo Automático</p>
                                            <p className="text-xs text-red-600">Inactivo</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Configuraciones de seguridad */}
                            <div className="space-y-6">
                                {/* Políticas de contraseña */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Políticas de Contraseña</h3>
                                    
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Longitud mínima</label>
                                                <p className="text-xs text-gray-500">Número mínimo de caracteres</p>
                                            </div>
                                            <select className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="6">6</option>
                                                <option value="8" defaultValue>8</option>
                                                <option value="10">10</option>
                                                <option value="12">12</option>
                                            </select>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Incluir mayúsculas</label>
                                                <p className="text-xs text-gray-500">Al menos una letra mayúscula</p>
                                            </div>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" defaultChecked />
                                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                            </label>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Incluir números</label>
                                                <p className="text-xs text-gray-500">Al menos un dígito</p>
                                            </div>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" defaultChecked />
                                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                            </label>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Caracteres especiales</label>
                                                <p className="text-xs text-gray-500">Al menos un símbolo (!@#$%^&*)</p>
                                            </div>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" />
                                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                            </label>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Expiración de contraseña</label>
                                                <p className="text-xs text-gray-500">Días antes de cambio obligatorio</p>
                                            </div>
                                            <select className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="30">30 días</option>
                                                <option value="60">60 días</option>
                                                <option value="90" defaultValue>90 días</option>
                                                <option value="0">Nunca</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Autenticación en dos pasos */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Autenticación en Dos Pasos (2FA)</h3>
                                    
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Habilitar 2FA</label>
                                                <p className="text-xs text-gray-500">Activar verificación en dos pasos</p>
                                            </div>
                                            <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" className="sr-only peer" />
                                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                            </label>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Método de verificación</label>
                                                <p className="text-xs text-gray-500">Cómo enviar el código de verificación</p>
                                            </div>
                                            <select className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="email" defaultValue>Email</option>
                                                <option value="sms">SMS</option>
                                                <option value="app">App móvil</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Bloqueo automático */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Bloqueo Automático</h3>
                                    
                                    <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Intentos fallidos máximos</label>
                                                <p className="text-xs text-gray-500">Número de intentos antes del bloqueo</p>
                                            </div>
                                            <select className="w-16 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="3">3</option>
                                                <option value="5" defaultValue>5</option>
                                                <option value="10">10</option>
                                            </select>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div>
                                                <label className="text-sm font-medium text-gray-700">Duración del bloqueo</label>
                                                <p className="text-xs text-gray-500">Tiempo antes de poder intentar de nuevo</p>
                                            </div>
                                            <select className="w-24 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                                <option value="5">5 min</option>
                                                <option value="15" defaultValue>15 min</option>
                                                <option value="30">30 min</option>
                                                <option value="60">1 hora</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Botones de acción */}
                                <div className="flex gap-4">
                                    <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Guardar Configuración
                                    </button>
                                    <button className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                        Restablecer por Defecto
                                    </button>
                                    <Link
                                        href={route('admin.security.index')}
                                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
                                    >
                                        Configuración Avanzada
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Sección Respaldo y Restauración */}
                    {activeSection === 'respaldo' && (
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800 mb-2">Respaldo y Restauración</h2>
                            <p className="text-gray-600 mb-8">Gestiona las copias de seguridad del sistema</p>
                            
                            {/* Estado actual */}
                            <div className="bg-white rounded-lg p-6 border border-gray-200 mb-6">
                                <h3 className="text-lg font-semibold text-gray-800 mb-4">Estado del Sistema</h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    <div className="text-center">
                                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                            <Database className="w-8 h-8 text-green-600" />
                                        </div>
                                        <p className="text-lg font-bold text-gray-900">232</p>
                                        <p className="text-sm text-gray-600">Registros de Asistencia</p>
                                    </div>
                                    
                                    <div className="text-center">
                                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                            <Users className="w-8 h-8 text-blue-600" />
                                        </div>
                                        <p className="text-lg font-bold text-gray-900">13</p>
                                        <p className="text-sm text-gray-600">Instructores</p>
                                    </div>
                                    
                                    <div className="text-center">
                                        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                            <Shield className="w-8 h-8 text-purple-600" />
                                        </div>
                                        <p className="text-lg font-bold text-gray-900">5</p>
                                        <p className="text-sm text-gray-600">Usuarios del Sistema</p>
                                    </div>
                                </div>
                            </div>

                            {/* Acciones de respaldo */}
                            <div className="space-y-6">
                                {/* Crear respaldo */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Crear Respaldo</h3>
                                    
                                    <div className="space-y-4">
                                        <div className="flex items-center gap-4">
                                            <input type="checkbox" id="incluir-asistencias" className="rounded border-gray-300 text-green-600 focus:ring-green-500" defaultChecked />
                                            <label htmlFor="incluir-asistencias" className="text-sm font-medium text-gray-700">
                                                Incluir registros de asistencia
                                            </label>
                                        </div>
                                        
                                        <div className="flex items-center gap-4">
                                            <input type="checkbox" id="incluir-instructores" className="rounded border-gray-300 text-green-600 focus:ring-green-500" defaultChecked />
                                            <label htmlFor="incluir-instructores" className="text-sm font-medium text-gray-700">
                                                Incluir datos de instructores
                                            </label>
                                        </div>
                                        
                                        <div className="flex items-center gap-4">
                                            <input type="checkbox" id="incluir-usuarios" className="rounded border-gray-300 text-green-600 focus:ring-green-500" defaultChecked />
                                            <label htmlFor="incluir-usuarios" className="text-sm font-medium text-gray-700">
                                                Incluir usuarios del sistema
                                            </label>
                                        </div>
                                        
                                        <div className="flex items-center gap-4">
                                            <input type="checkbox" id="incluir-configuracion" className="rounded border-gray-300 text-green-600 focus:ring-green-500" defaultChecked />
                                            <label htmlFor="incluir-configuracion" className="text-sm font-medium text-gray-700">
                                                Incluir configuraciones del sistema
                                            </label>
                                        </div>
                                    </div>

                                    <div className="mt-6">
                                        <button className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
                                            Generar Respaldo Completo
                                        </button>
                                    </div>
                                </div>

                                {/* Historial de respaldos */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Historial de Respaldos</h3>
                                    
                                    <div className="space-y-3">
                                        {[
                                            { fecha: '2025-11-10 14:30', tamaño: '2.4 MB', tipo: 'Completo', estado: 'Exitoso' },
                                            { fecha: '2025-11-05 09:15', tamaño: '2.1 MB', tipo: 'Completo', estado: 'Exitoso' },
                                            { fecha: '2025-11-01 16:45', tamaño: '1.8 MB', tipo: 'Parcial', estado: 'Exitoso' },
                                        ].map((backup, index) => (
                                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                                                        <Database className="w-4 h-4 text-green-600" />
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-medium text-gray-900">
                                                            Respaldo {backup.tipo} - {backup.fecha}
                                                        </p>
                                                        <p className="text-xs text-gray-500">
                                                            {backup.tamaño} • {backup.estado}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <button className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded text-sm">
                                                        Descargar
                                                    </button>
                                                    <button className="px-3 py-1 text-green-600 hover:bg-green-50 rounded text-sm">
                                                        Restaurar
                                                    </button>
                                                    <button className="px-3 py-1 text-red-600 hover:bg-red-50 rounded text-sm">
                                                        Eliminar
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                {/* Restaurar desde archivo */}
                                <div className="bg-white rounded-lg p-6 border border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Restaurar desde Archivo</h3>
                                    
                                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                                        <Database className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                                        <p className="text-gray-600 mb-2">Arrastra un archivo de respaldo aquí</p>
                                        <p className="text-sm text-gray-500 mb-4">o</p>
                                        <button className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded-lg transition-colors">
                                            Seleccionar Archivo
                                        </button>
                                        <p className="text-xs text-gray-500 mt-2">
                                            Archivos .sql, .backup o .zip solamente
                                        </p>
                                    </div>

                                    <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                        <p className="text-sm text-yellow-800">
                                            <strong>⚠️ Advertencia:</strong> La restauración sobrescribirá todos los datos actuales. 
                                            Asegúrate de tener un respaldo actual antes de proceder.
                                        </p>
                                    </div>
                                </div>

                                {/* Botones de acción principales */}
                                <div className="flex gap-4">
                                    <Link
                                        href={route('admin.backup.index')}
                                        className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors"
                                    >
                                        Gestión Completa de Respaldos
                                    </Link>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Otras secciones (placeholder) */}
                    {!['horarios', 'usuarios', 'mensajes', 'personalizacion', 'respaldo', 'seguridad'].includes(activeSection) && (
                        <div className="text-center py-12">
                            <h2 className="text-2xl font-bold text-gray-800 mb-4">
                                {activeSection === 'mensajes' && 'Mensajes flash / Notificaciones'}
                                {activeSection === 'personalizacion' && 'Personalización del Sistema'}
                                {activeSection === 'seguridad' && 'Seguridad y Contraseñas'}
                                {activeSection === 'respaldo' && 'Respaldo y Restauración'}
                            </h2>
                            <p className="text-gray-600">Esta sección está en desarrollo</p>
                        </div>
                    )}
                </main>
            </div>
        </SidebarLayout>
    );
}