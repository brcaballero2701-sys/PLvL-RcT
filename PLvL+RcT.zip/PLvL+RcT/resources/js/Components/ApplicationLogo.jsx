import LogoDisplay from './LogoDisplay';

export default function ApplicationLogo({ className = "", size = "auth", ...props }) {
    return (
        <LogoDisplay 
            className={className}
            size={size}
            variant="default"
            {...props}
        />
    );
}
